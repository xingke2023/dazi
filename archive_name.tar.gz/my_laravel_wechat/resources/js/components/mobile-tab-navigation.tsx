import { cn } from '@/lib/utils';
import { Link, usePage } from '@inertiajs/react';
import { Home, MessageSquare, Clock, User } from 'lucide-react';

interface TabItem {
    name: string;
    href: string;
    icon: React.ElementType;
    current: boolean;
}

export default function MobileTabNavigation() {
    const { url } = usePage();
    
    const tabs: TabItem[] = [
        {
            name: '首页',
            href: '/home',
            icon: Home,
            current: url === '/home',
        },
        {
            name: '大厅',
            href: '/hall',
            icon: MessageSquare,
            current: url === '/hall',
        },
        {
            name: '最新发布',
            href: '/latest',
            icon: Clock,
            current: url === '/latest',
        },
        {
            name: '我的',
            href: '/dashboard',
            icon: User,
            current: url === '/dashboard',
        },
    ];

    return (
        <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 dark:bg-gray-900 dark:border-gray-700">
            <div className="grid grid-cols-4 max-w-md mx-auto">
                {tabs.map((tab) => {
                    const Icon = tab.icon;
                    return (
                        <Link
                            key={tab.name}
                            href={tab.href}
                            className={cn(
                                'flex flex-col items-center justify-center py-3 text-xs font-medium transition-colors',
                                tab.current
                                    ? 'text-blue-600 dark:text-blue-400'
                                    : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
                            )}
                        >
                            <Icon
                                className={cn(
                                    'h-6 w-6 mb-1',
                                    tab.current
                                        ? 'text-blue-600 dark:text-blue-400'
                                        : 'text-gray-500 dark:text-gray-400'
                                )}
                            />
                            {tab.name}
                        </Link>
                    );
                })}
            </div>
        </div>
    );
}