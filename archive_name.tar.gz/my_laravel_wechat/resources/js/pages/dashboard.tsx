import UserProfileSection from '@/components/user-profile-section';
import MobileLayout from '@/layouts/mobile-layout';
import { Head, usePage } from '@inertiajs/react';

interface DashboardProps {
    auth: {
        user: {
            id: number;
            name: string;
            email: string;
            avatar?: string;
            wechat_openid?: string;
            wechat_nickname?: string;
            wechat_avatar?: string;
        };
    };
}

export default function Dashboard() {
    const { auth } = usePage<DashboardProps>().props;

    return (
        <MobileLayout>
            <Head title="我的" />
            <div className="px-4 py-6 space-y-6">
                <UserProfileSection user={auth.user} />
            </div>
        </MobileLayout>
    );
}
