# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Laravel application with React frontend using Inertia.js for seamless SPA-like experience. The stack includes:
- **Backend**: Laravel 12 with PHP 8.2+
- **Frontend**: React 19 with TypeScript
- **Build Tool**: Vite with Laravel Vite Plugin
- **Styling**: Tailwind CSS v4
- **UI Components**: Radix UI primitives with custom components
- **Database**: SQLite (default)
- **Testing**: PHPUnit for backend, no frontend tests configured

## Development Commands

### Backend Commands
```bash
# Start development server (includes frontend build, queue, logs)
composer run dev

# Start development server with SSR
composer run dev:ssr

# Run tests
composer run test
# or
php artisan test

# Run specific test
php artisan test --filter=TestName

# Code formatting (Laravel Pint)
vendor/bin/pint

# Database operations
php artisan migrate
php artisan migrate:fresh --seed
```

### Frontend Commands
```bash
# Build for production
npm run build

# Build with SSR
npm run build:ssr

# Development server (Vite only)
npm run dev

# Linting and formatting
npm run lint
npm run format
npm run format:check

# Type checking
npm run types
```

## Architecture Overview

### Backend Structure
- **Controllers**: Follow standard Laravel controller patterns with Inertia responses
- **Routes**: Organized in separate files (`web.php`, `auth.php`, `settings.php`)
- **Models**: Standard Eloquent models in `app/Models/`
- **Middleware**: Custom middleware for appearance handling and Inertia requests

### Frontend Structure
- **Entry Point**: `resources/js/app.tsx` - sets up Inertia app
- **Pages**: `resources/js/pages/` - Inertia page components
- **Components**: `resources/js/components/` - reusable UI components
- **Layouts**: `resources/js/layouts/` - page layout components
- **Hooks**: `resources/js/hooks/` - custom React hooks
- **UI Components**: `resources/js/components/ui/` - Radix UI-based components

### Key Patterns
- **Inertia.js**: Server-side routing with client-side navigation
- **SSR Ready**: Configured for server-side rendering via `resources/js/ssr.tsx`
- **Type Safety**: Full TypeScript setup with path aliases (`@/*` → `resources/js/*`)
- **Theme System**: Custom appearance/theme handling with local storage persistence

## Configuration Files

### Frontend Configuration
- `vite.config.ts`: Vite configuration with Laravel plugin, React, Tailwind
- `tsconfig.json`: TypeScript configuration with path aliases
- `eslint.config.js`: ESLint configuration for React and TypeScript
- `components.json`: Shadcn/ui component configuration

### Backend Configuration
- `config/inertia.php`: Inertia.js configuration with SSR enabled
- `phpunit.xml`: PHPUnit test configuration
- Database uses SQLite by default (`database/database.sqlite`)

## Testing

### Backend Tests
- Located in `tests/Feature/` and `tests/Unit/`
- Run with `php artisan test` or `composer run test`
- Uses SQLite in-memory database for testing

### Frontend
- No test framework currently configured
- Consider adding Jest/Vitest for component testing

## Development Notes

- The project uses Laravel's built-in authentication with Inertia.js
- Theme/appearance system is implemented with React hooks and local storage
- UI components follow Radix UI patterns with Tailwind styling
- Database migrations include users, cache, and jobs tables
- SSR is enabled and configured for production builds