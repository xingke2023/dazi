<?php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return Inertia::render('welcome');
})->name('welcome');

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('dashboard', function () {
        return Inertia::render('dashboard');
    })->name('dashboard');
    
    // Placeholder routes for mobile tabs
    Route::get('home', function () {
        return Inertia::render('home');
    })->name('home');
    
    Route::get('hall', function () {
        return Inertia::render('hall');
    })->name('hall');
    
    Route::get('latest', function () {
        return Inertia::render('latest');
    })->name('latest');
    
    // Placeholder routes for user menu items
    Route::get('my-joined', function () {
        return Inertia::render('my-joined');
    })->name('my-joined');
    
    Route::get('my-published', function () {
        return Inertia::render('my-published');
    })->name('my-published');
    
    Route::get('my-recommendations', function () {
        return Inertia::render('my-recommendations');
    })->name('my-recommendations');
    
    Route::get('my-wallet', function () {
        return Inertia::render('my-wallet');
    })->name('my-wallet');
});

require __DIR__.'/settings.php';
require __DIR__.'/auth.php';
require __DIR__.'/wechat_pay.php';
